import React from 'react'
import Contact from './Components/Contact/Contact'
const App = () => {
  return (
      <div>
          <Contact />
      </div>
  )    
}

export default App